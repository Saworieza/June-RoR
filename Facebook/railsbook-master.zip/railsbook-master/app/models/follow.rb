class Follow < ActiveRecord::Base
    acts_as_follow_store
end
