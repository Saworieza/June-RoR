class Mention < ActiveRecord::Base
  acts_as_mention_store
end
