# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Facebook::Application.config.secret_token = 'fdc6ab227a9464dd3db6f8f4478e21172368f000022d9b80f7136bbb969e99c593dd4cef61676a68765ea1bd238b775ad11f62b7a07a62ea4912467e1402475c'
